<?php
require_once __DIR__ . '/../models/Student.php';
require_once __DIR__ . '/../models/FeeCollection.php';

class StudentController {
    private $studentModel;
    
    public function __construct() {
        $this->studentModel = new Student();
    }
    
    public function addStudent($name, $rollNumber, $class, $parentMobile) {
        if ($this->studentModel->checkRollNumberExists($rollNumber)) {
            return "Roll number already exists.";
        }
        return $this->studentModel->addStudent($name, $rollNumber, $class, $parentMobile);
    }
    
    public function updateStudent($id, $name, $rollNumber, $class, $parentMobile) {
        if ($this->studentModel->checkRollNumberExists($rollNumber, $id)) {
            return "Roll number already exists.";
        }
        return $this->studentModel->updateStudent($id, $name, $rollNumber, $class, $parentMobile);
    }
    
    public function deleteStudent($id) {
        return $this->studentModel->deleteStudent($id);
    }
    
    public function getAllStudents() {
        return $this->studentModel->getAllStudents();
    }
    
    public function searchStudents($searchTerm) {
        return $this->studentModel->searchStudents($searchTerm);
    }
    
    public function getStudentById($id) {
        return $this->studentModel->getStudentById($id);
    }
    
    public function getStudentsByClass($class) {
        return $this->studentModel->getStudentsByClass($class);
    }
    
    public function getStudentCount() {
        return $this->studentModel->getStudentCount();
    }
    
    public function getStudentCountByClass() {
        return $this->studentModel->getStudentCountByClass();
    }
}

class FeeController {
    private $feeModel;
    private $studentModel;
    
    public function __construct() {
        $this->feeModel = new FeeCollection();
        $this->studentModel = new Student();
    }
    
    public function collectFee($studentId, $amountPaid, $month, $year, $paymentDate, $paymentMode, $remarks = '') {
        if ($this->feeModel->checkDuplicateFee($studentId, $month, $year)) {
            return "Fee for the month and year already collected for this student.";
        }
        return $this->feeModel->collectFee($studentId, $amountPaid, $month, $year, $paymentDate, $paymentMode, $remarks);
    }
    
    public function getFeeHistoryByStudent($studentId) {
        return $this->feeModel->getFeeHistoryByStudent($studentId);
    }
    
    public function getAllFeeCollections() {
        return $this->feeModel->getAllFeeCollections();
    }
    
    public function deleteFeeCollection($id) {
        return $this->feeModel->deleteFeeCollection($id);
    }
    
    public function getMonthlyCollectionStats($year) {
        return $this->feeModel->getMonthlyCollectionStats($year);
    }
    
    public function getClassWiseCollectionStats($month, $year) {
        return $this->feeModel->getClassWiseCollectionStats($month, $year);
    }
    
    public function getTotalCollectedAmount($month = null, $year = null) {
        return $this->feeModel->getTotalCollectedAmount($month, $year);
    }
    
    public function getTotalCollectedByClass($class, $month = null, $year = null) {
        return $this->feeModel->getTotalCollectedByClass($class, $month, $year);
    }
}
?>
