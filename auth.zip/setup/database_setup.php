<?php
// Database setup file - Run this once to create the database and tables

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'school_fee_system';

try {
    // Create database if not exists
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $database");
    echo "Database created successfully\n";
    
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create students table
    $createStudentsTable = "
        CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            roll_number VARCHAR(20) UNIQUE NOT NULL,
            class VARCHAR(20) NOT NULL,
            parent_mobile VARCHAR(15) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ";
    
    $pdo->exec($createStudentsTable);
    echo "Students table created successfully\n";
    
    // Create fee_collections table
    $createFeeCollectionsTable = "
        CREATE TABLE IF NOT EXISTS fee_collections (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            amount_paid DECIMAL(10,2) NOT NULL,
            month INT NOT NULL,
            year INT NOT NULL,
            payment_date DATE NOT NULL,
            payment_mode ENUM('Cash', 'Online', 'Cheque') NOT NULL,
            remarks TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            UNIQUE KEY unique_student_month_year (student_id, month, year)
        )
    ";
    
    $pdo->exec($createFeeCollectionsTable);
    echo "Fee collections table created successfully\n";
    
    // Create users table
    $createUsersTable = "
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ";
    
    $pdo->exec($createUsersTable);
    echo "Users table created successfully\n";
    
    // Create default admin user (password: admin123)
    $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $insertAdmin = $pdo->prepare("INSERT IGNORE INTO users (username, password) VALUES (?, ?)");
    $insertAdmin->execute(['admin', $adminPassword]);
    echo "Default admin user created successfully\n";
    
    // Insert sample students data
    $sampleStudents = [
        ['John Doe', 'STU001', 'Pre-Nursery', '9876543210'],
        ['Jane Smith', 'STU002', 'Nursery', '9876543211'],
        ['Mike Johnson', 'STU003', 'KG', '9876543212'],
        ['Sarah Wilson', 'STU004', 'Class 1', '9876543213'],
        ['David Brown', 'STU005', 'Class 2', '9876543214'],
        ['Emily Davis', 'STU006', 'Class 3', '9876543215'],
        ['Tom Anderson', 'STU007', 'Class 4', '9876543216'],
        ['Lisa Garcia', 'STU008', 'Class 5', '9876543217'],
        ['Robert Martinez', 'STU009', 'Class 6', '9876543218'],
        ['Anna Thompson', 'STU010', 'Class 7', '9876543219'],
        ['Chris Lee', 'STU011', 'Class 8', '9876543220'],
        ['Jessica White', 'STU012', 'Class 9', '9876543221'],
        ['Kevin Harris', 'STU013', 'Class 10', '9876543222']
    ];
    
    $insertStudent = $pdo->prepare("INSERT INTO students (name, roll_number, class, parent_mobile) VALUES (?, ?, ?, ?)");
    
    foreach ($sampleStudents as $student) {
        try {
            $insertStudent->execute($student);
        } catch (PDOException $e) {
            // Skip if student already exists
            if ($e->getCode() != 23000) {
                throw $e;
            }
        }
    }
    
    echo "Sample students data inserted successfully\n";
    echo "Database setup completed successfully!\n";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
