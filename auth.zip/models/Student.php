<?php
require_once __DIR__ . '/../config/database.php';

class Student {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    public function getAllStudents() {
        $sql = "SELECT * FROM students ORDER BY class, roll_number";
        return $this->db->fetchAll($sql);
    }
    
    public function getStudentById($id) {
        $sql = "SELECT * FROM students WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function searchStudents($searchTerm) {
        $sql = "SELECT * FROM students WHERE 
                name LIKE ? OR 
                roll_number LIKE ? OR 
                parent_mobile LIKE ? 
                ORDER BY class, roll_number";
        $searchParam = "%$searchTerm%";
        return $this->db->fetchAll($sql, [$searchParam, $searchParam, $searchParam]);
    }
    
    public function getStudentsByClass($class) {
        $sql = "SELECT * FROM students WHERE class = ? ORDER BY roll_number";
        return $this->db->fetchAll($sql, [$class]);
    }
    
    public function addStudent($name, $rollNumber, $class, $parentMobile) {
        $sql = "INSERT INTO students (name, roll_number, class, parent_mobile) VALUES (?, ?, ?, ?)";
        $this->db->execute($sql, [$name, $rollNumber, $class, $parentMobile]);
        return $this->db->lastInsertId();
    }
    
    public function updateStudent($id, $name, $rollNumber, $class, $parentMobile) {
        $sql = "UPDATE students SET name = ?, roll_number = ?, class = ?, parent_mobile = ? WHERE id = ?";
        return $this->db->execute($sql, [$name, $rollNumber, $class, $parentMobile, $id]);
    }
    
    public function deleteStudent($id) {
        $sql = "DELETE FROM students WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }
    
    public function checkRollNumberExists($rollNumber, $excludeId = null) {
        if ($excludeId) {
            $sql = "SELECT COUNT(*) as count FROM students WHERE roll_number = ? AND id != ?";
            $result = $this->db->fetch($sql, [$rollNumber, $excludeId]);
        } else {
            $sql = "SELECT COUNT(*) as count FROM students WHERE roll_number = ?";
            $result = $this->db->fetch($sql, [$rollNumber]);
        }
        return $result['count'] > 0;
    }
    
    public function getStudentCount() {
        $sql = "SELECT COUNT(*) as count FROM students";
        $result = $this->db->fetch($sql);
        return $result['count'];
    }
    
    public function getStudentCountByClass() {
        $sql = "SELECT class, COUNT(*) as count FROM students GROUP BY class ORDER BY 
                CASE class
                    WHEN 'Pre-Nursery' THEN 1
                    WHEN 'Nursery' THEN 2
                    WHEN 'KG' THEN 3
                    WHEN 'Class 1' THEN 4
                    WHEN 'Class 2' THEN 5
                    WHEN 'Class 3' THEN 6
                    WHEN 'Class 4' THEN 7
                    WHEN 'Class 5' THEN 8
                    WHEN 'Class 6' THEN 9
                    WHEN 'Class 7' THEN 10
                    WHEN 'Class 8' THEN 11
                    WHEN 'Class 9' THEN 12
                    WHEN 'Class 10' THEN 13
                END";
        return $this->db->fetchAll($sql);
    }
    
    public static function getClasses() {
        return [
            'Pre-Nursery',
            'Nursery',
            'KG',
            'Class 1',
            'Class 2',
            'Class 3',
            'Class 4',
            'Class 5',
            'Class 6',
            'Class 7',
            'Class 8',
            'Class 9',
            'Class 10'
        ];
    }
}
?>
