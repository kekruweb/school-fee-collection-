<?php
require_once __DIR__ . '/../config/database.php';

class FeeCollection {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    public function collectFee($studentId, $amountPaid, $month, $year, $paymentDate, $paymentMode, $remarks = '') {
        $sql = "INSERT INTO fee_collections (student_id, amount_paid, month, year, payment_date, payment_mode, remarks) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $this->db->execute($sql, [$studentId, $amountPaid, $month, $year, $paymentDate, $paymentMode, $remarks]);
        return $this->db->lastInsertId();
    }
    
    public function checkDuplicateFee($studentId, $month, $year) {
        $sql = "SELECT COUNT(*) as count FROM fee_collections WHERE student_id = ? AND month = ? AND year = ?";
        $result = $this->db->fetch($sql, [$studentId, $month, $year]);
        return $result['count'] > 0;
    }
    
    public function getFeeHistoryByStudent($studentId) {
        $sql = "SELECT fc.*, s.name, s.roll_number, s.class 
                FROM fee_collections fc 
                JOIN students s ON fc.student_id = s.id 
                WHERE fc.student_id = ? 
                ORDER BY fc.year DESC, fc.month DESC";
        return $this->db->fetchAll($sql, [$studentId]);
    }
    
    public function getAllFeeCollections() {
        $sql = "SELECT fc.*, s.name, s.roll_number, s.class 
                FROM fee_collections fc 
                JOIN students s ON fc.student_id = s.id 
                ORDER BY fc.created_at DESC";
        return $this->db->fetchAll($sql);
    }
    
    public function getFeeCollectionsByDateRange($startDate, $endDate) {
        $sql = "SELECT fc.*, s.name, s.roll_number, s.class 
                FROM fee_collections fc 
                JOIN students s ON fc.student_id = s.id 
                WHERE fc.payment_date BETWEEN ? AND ? 
                ORDER BY fc.payment_date DESC";
        return $this->db->fetchAll($sql, [$startDate, $endDate]);
    }
    
    public function getFeeCollectionsByClass($class) {
        $sql = "SELECT fc.*, s.name, s.roll_number, s.class 
                FROM fee_collections fc 
                JOIN students s ON fc.student_id = s.id 
                WHERE s.class = ? 
                ORDER BY fc.created_at DESC";
        return $this->db->fetchAll($sql, [$class]);
    }
    
    public function getFeeCollectionsByMonth($month, $year) {
        $sql = "SELECT fc.*, s.name, s.roll_number, s.class 
                FROM fee_collections fc 
                JOIN students s ON fc.student_id = s.id 
                WHERE fc.month = ? AND fc.year = ? 
                ORDER BY s.class, s.roll_number";
        return $this->db->fetchAll($sql, [$month, $year]);
    }
    
    public function getTotalCollectedAmount($month = null, $year = null) {
        if ($month && $year) {
            $sql = "SELECT COALESCE(SUM(amount_paid), 0) as total FROM fee_collections WHERE month = ? AND year = ?";
            $result = $this->db->fetch($sql, [$month, $year]);
        } else {
            $sql = "SELECT COALESCE(SUM(amount_paid), 0) as total FROM fee_collections";
            $result = $this->db->fetch($sql);
        }
        return $result['total'];
    }
    
    public function getTotalCollectedByClass($class, $month = null, $year = null) {
        if ($month && $year) {
            $sql = "SELECT COALESCE(SUM(fc.amount_paid), 0) as total 
                    FROM fee_collections fc 
                    JOIN students s ON fc.student_id = s.id 
                    WHERE s.class = ? AND fc.month = ? AND fc.year = ?";
            $result = $this->db->fetch($sql, [$class, $month, $year]);
        } else {
            $sql = "SELECT COALESCE(SUM(fc.amount_paid), 0) as total 
                    FROM fee_collections fc 
                    JOIN students s ON fc.student_id = s.id 
                    WHERE s.class = ?";
            $result = $this->db->fetch($sql, [$class]);
        }
        return $result['total'];
    }
    
    public function getMonthlyCollectionStats($year) {
        $sql = "SELECT month, SUM(amount_paid) as total_amount, COUNT(*) as total_payments 
                FROM fee_collections 
                WHERE year = ? 
                GROUP BY month 
                ORDER BY month";
        return $this->db->fetchAll($sql, [$year]);
    }
    
    public function getClassWiseCollectionStats($month, $year) {
        $sql = "SELECT s.class, SUM(fc.amount_paid) as total_amount, COUNT(*) as total_payments 
                FROM fee_collections fc 
                JOIN students s ON fc.student_id = s.id 
                WHERE fc.month = ? AND fc.year = ? 
                GROUP BY s.class 
                ORDER BY CASE s.class
                    WHEN 'Pre-Nursery' THEN 1
                    WHEN 'Nursery' THEN 2
                    WHEN 'KG' THEN 3
                    WHEN 'Class 1' THEN 4
                    WHEN 'Class 2' THEN 5
                    WHEN 'Class 3' THEN 6
                    WHEN 'Class 4' THEN 7
                    WHEN 'Class 5' THEN 8
                    WHEN 'Class 6' THEN 9
                    WHEN 'Class 7' THEN 10
                    WHEN 'Class 8' THEN 11
                    WHEN 'Class 9' THEN 12
                    WHEN 'Class 10' THEN 13
                END";
        return $this->db->fetchAll($sql, [$month, $year]);
    }
    
    public function deleteFeeCollection($id) {
        $sql = "DELETE FROM fee_collections WHERE id = ?";
        return $this->db->execute($sql, [$id]);
    }
    
    public static function getMonths() {
        return [
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4 => 'April',
            5 => 'May',
            6 => 'June',
            7 => 'July',
            8 => 'August',
            9 => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December'
        ];
    }
    
    public static function getPaymentModes() {
        return ['Cash', 'Online', 'Cheque'];
    }
}
?>
